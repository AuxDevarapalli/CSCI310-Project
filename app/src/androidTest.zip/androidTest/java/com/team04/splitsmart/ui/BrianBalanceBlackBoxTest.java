package com.team04.splitsmart.ui;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;
import static org.junit.Assert.assertTrue;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.team04.splitsmart.BuildConfig;
import com.team04.splitsmart.R;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

/**
 * Project 2.4 black-box tests. Author: Brian Shi (brianshi@usc.edu).
 * Balance and settlement UI validation (FR 4.1 - 4.4) using the pre-seeded demo data
 * for Alice (alice.demo@usc.edu). Requires the Firebase emulator / emulatorHost flag.
 */
@RunWith(AndroidJUnit4.class)
public class BrianBalanceBlackBoxTest {

    @Before
    public void signInAsAlice() throws Exception {
        assertTrue("Use -Psplitsmart.emulatorHost=10.0.2.2",
                !BuildConfig.FIREBASE_EMULATOR_HOST.isEmpty());
        FirebaseAuth auth = FirebaseAuth.getInstance();
        InstrumentationRegistry.getInstrumentation().runOnMainSync(auth::signOut);
        Tasks.await(auth.signInWithEmailAndPassword(
                "alice.demo@usc.edu", "splitsmart-demo"), 20, TimeUnit.SECONDS);
    }

    // BR-B01: Apartment 4B displays $4.00 Total to Pay and $15.00 Total to Receive.
    @Test
    public void apartmentShowsSeparateTotals() {
        try (ActivityScenario<GroupListActivity> ignored = ActivityScenario.launch(GroupListActivity.class)) {
            onView(withText("Apartment 4B")).perform(click());
            onView(withText("Balances")).perform(click());
            onView(withId(R.id.balance_total_pay)).check(matches(withText("$4.00")));
            onView(withId(R.id.balance_total_receive)).check(matches(withText("$15.00")));
        }
    }

    // BR-B02: Apartment 4B displays "Bob owes you $10.00".
    @Test
    public void apartmentShowsBobOwesAliceTenDollars() {
        try (ActivityScenario<GroupListActivity> ignored = ActivityScenario.launch(GroupListActivity.class)) {
            onView(withText("Apartment 4B")).perform(click());
            onView(withText("Balances")).perform(click());
            onView(withText("Bob owes you $10.00")).check(matches(isDisplayed()));
        }
    }

    // BR-B03: Apartment 4B displays "You owe David $4.00".
    @Test
    public void apartmentShowsAliceOwesDavidFourDollars() {
        try (ActivityScenario<GroupListActivity> ignored = ActivityScenario.launch(GroupListActivity.class)) {
            onView(withText("Apartment 4B")).perform(click());
            onView(withText("Balances")).perform(click());
            onView(withText("You owe David $4.00")).check(matches(isDisplayed()));
        }
    }

    // BR-B04: Road Trip starts at $11.00 debt; recording a $5 settlement reduces it to $6.00 ("You owe Bob $6.00").
    @Test
    public void roadTripSettlementReducesDebtToSixDollars() {
        try (ActivityScenario<GroupListActivity> ignored = ActivityScenario.launch(GroupListActivity.class)) {
            onView(withText("Road Trip")).perform(click());
            onView(withText("Balances")).perform(click());
            onView(withText("You owe Bob $11.00")).check(matches(isDisplayed()));

            onView(withText("Settle up")).perform(click());
            onView(withId(R.id.settlement_amount)).perform(scrollTo(), replaceText("5.00"), closeSoftKeyboard());
            onView(withId(R.id.settlement_save_button)).perform(scrollTo(), click());

            onView(withText("You owe Bob $6.00")).check(matches(isDisplayed()));
        } finally {
            cleanupRoadTripSettlements();
        }
    }

    // BR-B05: Study Group does not simplify chain debt (Alice owes Bob $10, but Alice and Carol remain settled up).
    @Test
    public void studyGroupDoesNotSimplifyChainDebt() {
        try (ActivityScenario<GroupListActivity> ignored = ActivityScenario.launch(GroupListActivity.class)) {
            onView(withText("Study Group")).perform(click());
            onView(withText("Balances")).perform(click());
            onView(withText("You owe Bob $10.00")).check(matches(isDisplayed()));
            onView(withText("You and Carol are settled up")).check(matches(isDisplayed()));
        }
    }

    private static void cleanupRoadTripSettlements() {
        try {
            FirebaseFirestore firestore = FirebaseFirestore.getInstance();
            Tasks.await(firestore.collection("groups")
                    .whereEqualTo("name", "Road Trip")
                    .get()
                    .continueWithTask(task -> {
                        if (!task.isSuccessful() || task.getResult() == null || task.getResult().isEmpty()) {
                            return Tasks.forResult(null);
                        }
                        String groupId = task.getResult().getDocuments().get(0).getId();
                        return firestore.collection("groups").document(groupId)
                                .collection("transactions")
                                .whereEqualTo("type", "SETTLEMENT")
                                .whereEqualTo("amountCents", 500L)
                                .get()
                                .continueWithTask(txTask -> {
                                    if (!txTask.isSuccessful() || txTask.getResult() == null) {
                                        return Tasks.forResult(null);
                                    }
                                    for (DocumentSnapshot doc : txTask.getResult().getDocuments()) {
                                        doc.getReference().delete();
                                    }
                                    return Tasks.forResult(null);
                                });
                    }), 10, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }
}
